// One six-second content cycle for selected cards, previews and seal notices:
// 0–1500ms hold text; 1500–2000ms fade to overlay; 2000–3500ms hold;
// 3500–4500ms fade to text; 4500–6000ms hold text. CSS preserves render phase.
export const CARD_CONTENT_CYCLE_MS = 6000;

export function cardContentCycleElapsed(startedAt, now = Date.now()) {
  const epoch = Number(startedAt);
  return Number.isFinite(epoch) && epoch > 0
    ? Math.max(0, now - epoch) % CARD_CONTENT_CYCLE_MS : 0;
}
