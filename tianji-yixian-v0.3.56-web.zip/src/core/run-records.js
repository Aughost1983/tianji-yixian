import { CARDS } from "../data/cards.js";
import { ARTIFACTS } from "../data/artifacts.js";
import { ADVANCED_UPGRADE_CHAINS } from "../data/progression.js";

const previousAdvancedId = Object.fromEntries(
  Object.entries(ADVANCED_UPGRADE_CHAINS).map(([before, after]) => [after, before])
);

function natural(value) { return Math.max(0, Math.floor(Number(value) || 0)); }

function advancedFamily(cardId) {
  let current = cardId;
  while (previousAdvancedId[current]) current = previousAdvancedId[current];
  return current;
}

function advancedRank(card) {
  let rank = card?.upgraded ? 1 : 0;
  let current = card?.cardId;
  while (previousAdvancedId[current]) { rank += 2; current = previousAdvancedId[current]; }
  return rank;
}

export function ensureAdvancedSkillOrder(player) {
  if (!player) return [];
  if (!Array.isArray(player.advancedSkillOrder)) player.advancedSkillOrder = [];
  if (!player.advancedSkillHistory || typeof player.advancedSkillHistory !== "object" || Array.isArray(player.advancedSkillHistory)) {
    player.advancedSkillHistory = {};
  }
  const order = player.advancedSkillOrder;
  for (const card of player.deck ?? []) {
    if (!CARDS[card.cardId]?.tags?.includes("advanced")) continue;
    const family = advancedFamily(card.cardId);
    if (!order.includes(family)) order.push(family);
    const previous = player.advancedSkillHistory[family];
    if (!previous || !CARDS[previous.cardId]?.tags?.includes("advanced")
      || advancedFamily(previous.cardId) !== family || advancedRank(card) > advancedRank(previous)) {
      player.advancedSkillHistory[family] = { cardId: card.cardId, upgraded: Boolean(card.upgraded) };
    }
  }
  return order;
}

export function noteAdvancedSkill(player, cardId, upgraded = false) {
  if (!CARDS[cardId]?.tags?.includes("advanced")) return;
  const order = ensureAdvancedSkillOrder(player);
  const family = advancedFamily(cardId);
  if (!order.includes(family)) order.push(family);
  const previous = player.advancedSkillHistory[family];
  const candidate = { cardId, upgraded: Boolean(upgraded) };
  if (!previous || advancedRank(candidate) > advancedRank(previous)) player.advancedSkillHistory[family] = candidate;
}

export function createRunRecords() {
  return {
    battles: 0, pursuitBattles: 0, pursuersDefeated: 0, highestPursuit: 0,
    enemiesDefeated: 0, escapes: 0, escapeFailures: 0, deaths: 0,
    roundsTotal: 0, roundsRecorded: 0, fastestRound: 0, longestRound: 0,
    longestEnemyKeys: [], damageTaken: 0, highestTurnDamage: 0, highestRoundDamage: 0, cardPlays: {},
  };
}

export function ensureRunRecords(state) {
  if (!state?.run) return null;
  const defaults = createRunRecords();
  const records = state.run.records && typeof state.run.records === "object" ? state.run.records : {};
  for (const [key, value] of Object.entries(defaults)) {
    if (Array.isArray(value)) records[key] = Array.isArray(records[key]) ? records[key] : [];
    else if (value && typeof value === "object") records[key] = records[key] && typeof records[key] === "object" && !Array.isArray(records[key]) ? records[key] : {};
    else records[key] = natural(records[key]);
  }
  state.run.records = records;
  if (state?.map) records.highestPursuit = Math.max(records.highestPursuit, natural(state.map.pursuit));
  ensureAdvancedSkillOrder(state.player);
  return records;
}

export function recordPursuitPeak(state) {
  const records = ensureRunRecords(state);
  if (records) records.highestPursuit = Math.max(records.highestPursuit, natural(state.map?.pursuit));
}

export function recordBattleStart(state) {
  const combat = state?.combat;
  if (!combat || combat.debugEncounter || combat.runRecordStarted) return;
  const records = ensureRunRecords(state);
  if (!records) return;
  combat.runRecordStarted = true;
  records.battles += 1;
  if (combat.pursuit) records.pursuitBattles += 1;
  recordPursuitPeak(state);
}

export function recordEnemyDefeat(state) {
  if (state?.combat?.debugEncounter || !state?.combat?.runRecordStarted) return;
  const records = ensureRunRecords(state);
  if (records) records.enemiesDefeated += 1;
}

export function recordBattleOutcome(state, outcome) {
  const combat = state?.combat;
  if (!combat?.runRecordStarted || combat.runRecordOutcome || combat.debugEncounter) return;
  const records = ensureRunRecords(state);
  if (!records) return;
  finishRoundDamage(state);
  combat.runRecordOutcome = outcome;
  const rounds = Math.max(1, natural(combat.round));
  records.roundsTotal += rounds;
  records.roundsRecorded += 1;
  if (!records.fastestRound || rounds < records.fastestRound) records.fastestRound = rounds;
  if (rounds > records.longestRound) {
    records.longestRound = rounds;
    records.longestEnemyKeys = (combat.enemies ?? []).map((enemy) => enemy.displayNameKey ?? enemy.nameKey).filter(Boolean);
  }
  if (outcome === "victory" && combat.pursuit) records.pursuersDefeated += 1;
  if (outcome === "escape") records.escapes += 1;
}

export function recordEscapeFailure(state) {
  if (state?.combat?.debugEncounter || !state?.combat?.runRecordStarted) return;
  const records = ensureRunRecords(state);
  if (records) records.escapeFailures += 1;
}

export function recordDeath(state) {
  const records = ensureRunRecords(state);
  if (records) records.deaths += 1;
}

export function recordPlayerCardUse(state, card) {
  if (state?.combat?.debugEncounter || !state?.combat?.runRecordStarted || !card?.cardId) return;
  const records = ensureRunRecords(state);
  if (!records) return;
  const key = `${card.cardId}:${card.upgraded ? "upgraded" : "base"}`;
  records.cardPlays[key] = natural(records.cardPlays[key]) + 1;
}

// A round includes the player's card phase and every following enemy action.
// Finalize it both at the normal enemy-phase boundary and at early battle exits.
export function finishRoundDamage(state) {
  const combat = state?.combat;
  if (!combat?.runRecordStarted || combat.debugEncounter || combat.recordRoundDamageClosed) return;
  const records = ensureRunRecords(state);
  if (!records) return;
  records.highestRoundDamage = Math.max(records.highestRoundDamage, natural(combat.recordRoundDamage));
  combat.recordRoundDamageClosed = true;
}

export function recordCombatDamage(state, target, beforeHp, afterHp, { source = null, playedCard = false } = {}) {
  const combat = state?.combat;
  if (!combat?.runRecordStarted || combat.debugEncounter || combat.runRecordOutcome) return;
  const damage = Math.max(0, natural(beforeHp) - natural(afterHp));
  if (!damage) return;
  const records = ensureRunRecords(state);
  if (!records) return;
  if (target?.kind === "player") records.damageTaken += damage;
  if (playedCard && combat.activePlayedCardUid && combat.phase === "player"
    && source?.kind === "player" && target?.kind === "enemy") {
    combat.recordPlayerTurnDamage = natural(combat.recordPlayerTurnDamage) + damage;
    combat.recordRoundDamage = natural(combat.recordRoundDamage) + damage;
    records.highestTurnDamage = Math.max(records.highestTurnDamage, combat.recordPlayerTurnDamage);
  }
  // During the enemy phase, all actual enemy HP loss belongs to the preceding
  // player turn: Burn, Heart Demon, Dark Force, counters and enemy self-damage.
  if (combat.phase === "enemy" && target?.kind === "enemy") {
    combat.recordRoundDamage = natural(combat.recordRoundDamage) + damage;
  }
}

export function completionRecord(state) {
  const records = ensureRunRecords(state) ?? createRunRecords();
  const player = state?.player ?? {};
  const order = ensureAdvancedSkillOrder(player);
  const advanced = order.filter((family) => CARDS[family]?.tags?.includes("advanced")).map((family) => {
    const saved = player.advancedSkillHistory?.[family];
    return saved && CARDS[saved.cardId]?.tags?.includes("advanced") && advancedFamily(saved.cardId) === family
      ? { cardId: saved.cardId, upgraded: Boolean(saved.upgraded) }
      : { cardId: family, upgraded: false }; // Older saves retain the family order, but not a deleted card's former rank.
  });
  const refineStats = state?.run?.refineStats ?? {};
  const restOutcomes = {
    manualStudy: { success: natural(refineStats.manualSuccess), failure: natural(refineStats.manualFailure) },
    refineBody: { success: natural(refineStats.bodySuccess), failure: natural(refineStats.bodyFailure) },
    refineSpirit: { success: natural(refineStats.success), failure: natural(refineStats.failure) },
    harmonize: { success: natural(refineStats.harmonizeSuccess), failure: natural(refineStats.harmonizeFailure) },
  };
  const mostUsed = Object.entries(records.cardPlays)
    .filter(([key, count]) => natural(count) > 0 && key !== "heartDemonCard:base")
    .sort((a, b) => natural(b[1]) - natural(a[1]))[0];
  const [mostUsedId, mostUsedVariant] = mostUsed?.[0]?.split(":") ?? [];
  const endedAt = natural(state?.run?.completedAt) || Date.now();
  const elapsedSeconds = Number.isFinite(state?.run?.activeForegroundMs)
    ? Math.floor(Math.max(0, state.run.activeForegroundMs) / 1000)
    : Math.max(0, Math.floor((endedAt - natural(state?.run?.startedAt)) / 1000));
  return {
    styleId: state?.run?.styleId ?? player.styleId ?? "sword",
    elapsedSeconds,
    artifactIds: (player.ownedArtifacts ?? []).filter((id) => ARTIFACTS[id] && !ARTIFACTS[id].hidden),
    cardCount: (player.deck ?? []).length,
    advanced,
    mostUsed: mostUsed && CARDS[mostUsedId] ? { cardId: mostUsedId, upgraded: mostUsedVariant === "upgraded", count: natural(mostUsed[1]) } : null,
    battles: records.battles, pursuitBattles: records.pursuitBattles, pursuersDefeated: records.pursuersDefeated,
    highestPursuit: records.highestPursuit, enemiesDefeated: records.enemiesDefeated,
    escapes: records.escapes, escapeFailures: records.escapeFailures, deaths: records.deaths,
    averageRounds: records.roundsRecorded ? (records.roundsTotal / records.roundsRecorded).toFixed(1) : "0.0",
    fastestRound: records.fastestRound, longestRound: records.longestRound,
    longestEnemyKeys: [...records.longestEnemyKeys], damageTaken: records.damageTaken,
    highestTurnDamage: records.highestTurnDamage, highestRoundDamage: records.highestRoundDamage,
    restOutcomes,
  };
}

export function completeRun(state, now = Date.now()) {
  if (!state?.run) return;
  state.run.completed = true;
  state.run.completedAt ??= now;
  if (!state.run.completionRecord) {
    state.run.completionRecord = completionRecord(state);
  } else if (!state.run.completionRecord.restOutcomes) {
    // Extend an older finished save without resetting its frozen time or battle statistics.
    const updated = completionRecord(state);
    state.run.completionRecord.advanced = updated.advanced;
    state.run.completionRecord.restOutcomes = updated.restOutcomes;
  }
}
