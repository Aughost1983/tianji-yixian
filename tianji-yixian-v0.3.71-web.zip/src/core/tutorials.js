import { ARTIFACTS } from "../data/artifacts.js?v=v0.3.71";
import { addOwnedArtifact, isArtifactOwned } from "./state.js?v=v0.3.71";

// Learning belongs to the UI, not the run, rewind snapshots or resource cache.
export const TUTORIAL_SEEN_KEY = "tianji.tutorialHintsSeen";
export const TUTORIAL_PENDING_KEY = "tianji.tutorialHintsPending";
const validKey = (value) => typeof value === "string" && value.length <= 120
  && /^[\w.-]+$/.test(value) && !["__proto__", "constructor", "prototype"].includes(value);

export class TutorialHints {
  constructor(storage) {
    try { this.storage = storage ?? globalThis.localStorage; } catch { this.storage = null; }
    this.seen = new Set();
    this.pending = [];
    this.active = null;
    this.refreshSeen();
    const saved = this.read(TUTORIAL_PENDING_KEY);
    if (Array.isArray(saved)) {
      for (const hint of saved) {
        if (!hint || !validKey(hint.id) || !validKey(hint.bodyKey) || this.seen.has(hint.id)
          || this.pending.some((entry) => entry.id === hint.id)) continue;
        this.pending.push({ id: hint.id, bodyKey: hint.bodyKey });
      }
    }
  }

  read(key) {
    try { return JSON.parse(this.storage?.getItem(key) ?? "null"); } catch { return null; }
  }

  write(key, value) {
    // A blocked/full local store must not interrupt gameplay; session state still works.
    try { this.storage?.setItem(key, JSON.stringify(value)); } catch { /* best effort */ }
  }

  refreshSeen() {
    const saved = this.read(TUTORIAL_SEEN_KEY);
    if (!saved || typeof saved !== "object" || Array.isArray(saved)) return;
    for (const [id, value] of Object.entries(saved)) {
      if (validKey(id) && value === true) this.seen.add(id);
    }
  }

  enqueue(id, bodyKey = `tutorial.${id}`) {
    if (!validKey(id) || !validKey(bodyKey)) return false;
    this.refreshSeen();
    if (this.seen.has(id) || this.active?.id === id || this.pending.some((hint) => hint.id === id)) return false;
    this.pending.push({ id, bodyKey });
    this.write(TUTORIAL_PENDING_KEY, this.pending);
    return true;
  }

  activateNext(canShow = () => true) {
    if (this.active) return this.active;
    this.refreshSeen();
    this.pending = this.pending.filter((hint) => !this.seen.has(hint.id));
    // A hint for another screen waits without blocking a newly relevant hint.
    const index = this.pending.findIndex(canShow);
    if (index < 0) return null;
    this.active = this.pending.splice(index, 1)[0];
    this.seen.add(this.active.id);
    this.write(TUTORIAL_SEEN_KEY, Object.fromEntries([...this.seen].map((id) => [id, true])));
    this.write(TUTORIAL_PENDING_KEY, this.pending);
    return this.active;
  }

  dismiss() {
    if (!this.active) return false;
    this.active = null;
    return true;
  }
}

// Every actual acquisition uses the same hook. Initial/load-time inventory
// normalization does not count as acquiring a new artifact.
export function grantArtifactWithTutorial(app, artifactId, options) {
  const player = app.state?.player;
  if (!player) return false;
  const ownedBefore = isArtifactOwned(player, artifactId);
  const added = addOwnedArtifact(player, artifactId, options);
  if (added && !ownedBefore && artifactId !== "treasureToken" && !ARTIFACTS[artifactId]?.hidden) {
    app.showTutorialOnce?.("firstArtifact");
  }
  return added;
}
