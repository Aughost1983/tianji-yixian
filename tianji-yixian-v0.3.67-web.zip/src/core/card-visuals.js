// One six-second content cycle for selected cards, previews and seal notices:
// 0–500ms fade to overlay; 500–2000ms hold; 2000–3000ms fade to text;
// 3000–6000ms hold text. CSS uses the same boundaries with negative delay.
export const CARD_CONTENT_CYCLE_MS = 6000;

export function cardContentCycleElapsed(startedAt, now = Date.now()) {
  const epoch = Number(startedAt);
  return Number.isFinite(epoch) && epoch > 0
    ? Math.max(0, now - epoch) % CARD_CONTENT_CYCLE_MS : 0;
}
